# Copilot Instructions for Redux-DeepSeek Extension

## Overview
This project is a browser extension designed to interact with DeepSeek, a chat-based application. The extension facilitates communication with a backend server via sockets and provides a user interface for managing tasks, sending data, and processing responses.

### Key Components
1. **`content.js`**: Handles the injection of UI elements into the webpage, communication with the backend, and processing of user inputs and server responses.
2. **`backgroundeep.js`**: Manages background tasks, including socket communication and server status checks.
3. **`manifest.json`**: Defines the extension's metadata and permissions.

### Data Flow
- **Frontend (content.js)**: Injects UI elements into the webpage, collects user inputs, and sends data to the backend.
- **Backend (via sockets)**: Processes data and sends responses back to the extension.
- **UI Updates**: Updates the webpage based on server responses and user actions.

## Developer Workflows
### Building the Extension
Use the `web-ext` tool to build and test the extension:
```bash
web-ext build
web-ext run
```

### Debugging
- Use browser developer tools to inspect injected elements and console logs.
- Check socket communication using the `network` tab.

### Testing
- Ensure the extension works on both Chrome and Firefox.
- Test socket communication and UI updates thoroughly.

## Project-Specific Conventions
1. **UI Injection**: All UI elements are injected dynamically into the webpage. Use `document.createElement` and `appendChild` for creating and adding elements.
2. **Socket Communication**: Use `sendToSocket` for sending data and handle responses with `receiveIdsFromSocket`.
3. **Timeout Handling**: Implement timeouts for socket communication and UI updates to ensure reliability.
4. **Error Handling**: Log errors to the console and provide user feedback via the status element.

## Integration Points
- **DeepSeek**: The extension interacts with DeepSeek via its webpage and backend server.
- **Browser APIs**: Use `browser` or `chrome` APIs for extension-specific tasks.

## Examples
### UI Injection
```javascript
const container = document.createElement('div');
container.id = 'deepseek-line-sender';
document.body.appendChild(container);
```

### Socket Communication
```javascript
async function sendToSocket(data) {
    try {
        await fetch(`http://${SOCKET_HOST}:${SOCKET_PORT}/send`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
    } catch (error) {
        console.error('Error sending data to socket:', error);
    }
}
```

### Timeout Handling
```javascript
setTimeout(() => {
    console.log('Timeout reached, restarting chat...');
    window.location.href = 'https://chat.deepseek.com/';
}, 10000);
```

## Notes
- Always test changes on both Chrome and Firefox.
- Follow the existing patterns for UI injection and socket communication.
- Use meaningful console logs for debugging and error tracking.

Feel free to update this document as the project evolves.
