let stopTasksBtn;

const browserAPI = chrome;

let customSelectors = {
    'www.kimi.com': {
        name: 'Kimi',
        whitelisted: true,
        newChatButton: '/',
        responseContainer: 'pre',
        sendButton: 'div.send-button',
        textarea: 'div.chat-input-editor[role="textbox"]'
    },
    'aistudio.google.com': {
        name: 'Google AI Studio',
        whitelisted: true,
        newChatButton: 'https://aistudio.google.com/app/prompts/new_chat',
        responseContainer: 'pre',
        sendButton: 'button.ms-button-primary[aria-label*="Run"], button[type="submit"].ms-button-primary',
        textarea: 'textarea[formcontrolname="promptText"], textarea[aria-label="Enter a prompt"]'
    },
    'chat.deepseek.com': {
        name: 'DeepSeek Chat',
        whitelisted: true,
        newChatButton: 'https://chat.deepseek.com/',
        responseContainer: 'pre',
        sendButton: 'div.ds-icon-button > div.ds-icon-button__hover-bg:nth-of-type(1):nth(6)',
        textarea: 'textarea[placeholder="Message DeepSeek"]'
    }
};
let runningIntervals = [];
let runningTimeouts = [];
let currentFilePath = null;
let isCustomConfigMode = false;
let customConfigStep = 0;
let tempCustomConfig = {};
const RS_STATE_KEY = 'resplitter_process_state';

async function saveProcessState(state) {
    await browserAPI.storage.local.set({ [RS_STATE_KEY]: state });
}

async function getProcessState() {
    const res = await browserAPI.storage.local.get([RS_STATE_KEY]);
    return res[RS_STATE_KEY] || null;
}

async function clearProcessState() {
    await browserAPI.storage.local.remove([RS_STATE_KEY]);
}
async function saveCustomSelectors() {
    try {
        await browserAPI.storage.local.set({ customSelectors: customSelectors });
        console.log('Custom selectors saved');
    } catch (error) {
        console.error('Error saving custom selectors:', error);
    }
}
async function loadCustomSelectors() {
    try {
        const result = await browserAPI.storage.local.get(['customSelectors']);
        if (result.customSelectors) {
            customSelectors = { ...customSelectors, ...result.customSelectors };
            console.log('Custom selectors loaded:', customSelectors);
        }
    } catch (error) {
        console.error('Error loading custom selectors:', error);
    }
}
function getCurrentSiteSelectors() {
    const hostname = window.location.hostname;
    return customSelectors[hostname] || null;
}

function highlightElement(element) {
    element.style.outline = '3px solid #ff6b6b';
    element.style.backgroundColor = 'rgba(255, 107, 107, 0.1)';
}

function unhighlightElement(element) {
    element.style.outline = '';
    element.style.backgroundColor = '';
}
function createCustomConfigOverlay() {
    const overlay = document.createElement('div');
    overlay.id = 'custom-config-overlay';
    overlay.style = `
        position: fixed !important;
        top: 0 !important;
        left: 0 !important;
        width: 100vw !important;
        height: 100vh !important;
        z-index: 999999 !important;
        display: flex !important;
        justify-content: center !important;
        align-items: flex-start !important;
        pointer-events: none !important;
        padding-top: 20px !important;
    `;

    const modal = document.createElement('div');
    modal.style = `
        background: #2a2929ff !important;
        border: 1px solid #555 !important;
        border-radius: 8px !important;
        padding: 24px !important;
        max-width: 500px !important;
        color: white !important;
        pointer-events: auto !important;
    `;

    const title = document.createElement('h3');
    title.textContent = 'Configure Custom AI Site';
    title.style = 'margin: 0 0 16px 0 !important; color: #7fdfff !important;';
    modal.appendChild(title);

    const instructions = document.createElement('div');
    instructions.id = 'config-instructions';
    instructions.style = 'margin-bottom: 16px !important; line-height: 1.5 !important;';
    modal.appendChild(instructions);

    const buttonContainer = document.createElement('div');
    buttonContainer.style = 'text-align: center !important;';

    const cancelBtn = document.createElement('button');
    cancelBtn.textContent = 'Cancel';
    cancelBtn.style = `
        margin-right: 12px !important;
        padding: 8px 16px !important;
        background: #555 !important;
        color: white !important;
        border: 1px solid #888 !important;
        border-radius: 4px !important;
        cursor: pointer !important;
    `;
    cancelBtn.onclick = function () {
        isCustomConfigMode = false;
        customConfigStep = 0;
        tempCustomConfig = {};
        document.body.removeChild(overlay);
        document.removeEventListener('mouseover', handleConfigHover);
        document.removeEventListener('click', handleConfigClick);
        const extensionContainer = document.getElementById('deepseek-line-sender');
        if (extensionContainer) {
            extensionContainer.style.display = 'block';
        }
    };

    const nextBtn = document.createElement('button');
    nextBtn.id = 'config-next-btn';
    nextBtn.textContent = 'Next';
    nextBtn.style = `
        padding: 8px 16px !important;
        background: #4a9eff !important;
        color: white !important;
        border: 1px solid #888 !important;
        border-radius: 4px !important;
        cursor: pointer !important;
        display: none !important;
    `;

    buttonContainer.appendChild(cancelBtn);
    buttonContainer.appendChild(nextBtn);
    modal.appendChild(buttonContainer);

    overlay.appendChild(modal);
    document.body.appendChild(overlay);

    return { overlay, instructions, nextBtn };
}
function handleConfigHover(e) {
    if (!isCustomConfigMode) return;

    let target = e.target;
    if (target.closest('#custom-config-overlay')) {
        return;
    }
    const clickeableTypes = ['button', 'div', 'a', 'span', 'input'];
    if (!clickeableTypes.includes(target.tagName.toLowerCase())) {
        const clickeableParent = target.closest('button, div, a, span, input');
        if (clickeableParent) {
            target = clickeableParent;
        }
    }
    document.querySelectorAll('[data-config-highlighted]').forEach(el => {
        unhighlightElement(el);
        el.removeAttribute('data-config-highlighted');
    });
    highlightElement(target);
    target.setAttribute('data-config-highlighted', 'true');
}
function handleConfigClick(e) {
    if (!isCustomConfigMode) return;

    let target = e.target;
    if (target.closest('#custom-config-overlay')) {
        return;
    }

    e.preventDefault();
    e.stopPropagation();

    const hostname = window.location.hostname;
    function findClickableElement(element) {
        const clickableSelectors = ['button', 'a', '[role="button"]', '[onclick]', '[data-testid]',
            'div[class*="button"]', 'div[class*="btn"]', 'span[class*="button"]', 'span[class*="btn"]'];
        for (const selector of clickableSelectors) {
            if (element.matches && element.matches(selector)) {
                return element;
            }
        }
        let parent = element.parentElement;
        while (parent && parent !== document.body) {
            for (const selector of clickableSelectors) {
                if (parent.matches && parent.matches(selector)) {
                    return parent;
                }
            }
            parent = parent.parentElement;
        }

        return element;
    }
    target = findClickableElement(target);
    function generateSelector(element, includeContext = false) {
        const isHash = (str) => {
            if (!str) return false;
            return /[0-9]/.test(str) || str.startsWith('_') || str.length > 25;
        };

        if (element.id && !isHash(element.id)) {
            return `#${element.id}`;
        }

        let selector = element.tagName.toLowerCase();
        let classString = "";
        if (typeof element.className === "string") {
            classString = element.className;
        } else if (element.className && element.className.baseVal) {
            classString = element.className.baseVal;
        } else if (element.classList) {
            classString = Array.from(element.classList).join(" ");
        }

        const classes = Array.from(element.classList).filter(c => !isHash(c));

        const importantClasses = classes.filter(cls => {
            const lowerCls = cls.toLowerCase();
            return lowerCls.includes('button') || lowerCls.includes('btn') ||
                lowerCls.includes('chat') || lowerCls.includes('new') ||
                lowerCls.includes('send') || lowerCls.includes('submit') ||
                lowerCls.includes('link') || lowerCls.includes('action') ||
                lowerCls.includes('input') || lowerCls.includes('editor') ||
                lowerCls.includes('textarea') || lowerCls.includes('prompt');
        }).slice(0, 3);

        const selectedClasses = importantClasses.length > 0 ? importantClasses : classes.slice(0, 2);

        if (selectedClasses.length > 0) {
            selector += "." + selectedClasses.join(".");
        }

        const topAttrs = ["aria-label", "placeholder", "formcontrolname", "data-testid"];
        for (const attr of topAttrs) {
            if (element.hasAttribute(attr)) {
                const value = element.getAttribute(attr);
                if (value && value.length < 60 && !isHash(value)) {
                    return `${element.tagName.toLowerCase()}[${attr}="${value.replace(/"/g, '\\"')}"]`;
                }
            }
        }

        if (element.tagName === 'BUTTON' || selector.includes('button') || selector.includes('btn')) {
            const text = element.textContent.trim();
            if (text && text.length > 0 && text.length < 20 && !text.includes('\n')) {
                selector += `:contains("${text}")`;
            }
        }

        const getSimplifiedSelector = (el) => {
            let s = el.tagName.toLowerCase();
            if (el.id && !isHash(el.id)) return `#${el.id}`;
            const c = Array.from(el.classList).filter(cls => !isHash(cls));
            if (c.length > 0) s += "." + c[0];
            return s;
        };

        if (document.querySelectorAll(selector).length > 1) {
            const prev = element.previousElementSibling;
            if (prev) {
                const prevSel = getSimplifiedSelector(prev);
                if (document.querySelectorAll(`${prevSel} + ${selector}`).length === 1) {
                    return `${prevSel} + ${selector}`;
                }
            }
            const next = element.nextElementSibling;
            if (next) {
                const nextSel = getSimplifiedSelector(next);
                try {
                    if (document.querySelectorAll(`${selector}:has(+ ${nextSel})`).length === 1) {
                        return `${selector}:has(+ ${nextSel})`;
                    }
                } catch (e) { }
            }
        }

        if (includeContext || document.querySelectorAll(selector).length > 1) {
            const parent = element.parentElement;
            if (parent && parent !== document.body) {
                const parentSel = getSimplifiedSelector(parent);
                const siblings = Array.from(parent.children).filter(child => child.tagName === element.tagName);
                const position = siblings.indexOf(element);
                if (siblings.length > 1 && position >= 0) {
                    selector += `:nth-of-type(${position + 1})`;
                }
                selector = `${parentSel} > ${selector}`;
            }
        }

        const allMatches = document.querySelectorAll(selector);
        if (allMatches.length > 1) {
            const globalIndex = Array.from(allMatches).indexOf(element);
            if (globalIndex >= 0) {
                selector = `${selector}:nth(${globalIndex})`;
            }
        }

        return selector;
    }

    const selector = generateSelector(target);
    const instructions = document.getElementById('config-instructions');
    const nextBtn = document.getElementById('config-next-btn');

    function findInputElement(element) {
        if (element.tagName === 'TEXTAREA' ||
            element.getAttribute('contenteditable') === 'true' ||
            element.getAttribute('role') === 'textbox') {
            return element;
        }
        let parent = element.parentElement;
        while (parent && parent !== document.body) {
            if (parent.tagName === 'TEXTAREA' ||
                parent.getAttribute('contenteditable') === 'true' ||
                parent.getAttribute('role') === 'textbox') {
                return parent;
            }
            const childTextarea = parent.querySelector('textarea, [contenteditable="true"], [role="textbox"]');
            if (childTextarea && parent.contains(element)) {
                return childTextarea;
            }
            parent = parent.parentElement;
        }
        return element;
    }

    switch (customConfigStep) {
        case 0:
            const inputElement = findInputElement(target);
            const textareaSelector = generateSelector(inputElement, true);
            tempCustomConfig.textarea = textareaSelector;
            instructions.innerHTML = `
                <strong>Step 1/3:</strong> Text area selected ✓<br>
                <code>${textareaSelector}</code><br><br>
                <strong>Step 2/3:</strong> Now click on the <strong>Send button</strong>
            `;
            customConfigStep = 1;
            break;
        case 1:
            const sendButtonSelector = generateSelector(target, true);
            tempCustomConfig.sendButton = sendButtonSelector;
            isCustomConfigMode = false;
            document.removeEventListener('mouseover', handleConfigHover);
            document.removeEventListener('click', handleConfigClick, true);
            document.querySelectorAll('[data-config-highlighted]').forEach(el => {
                unhighlightElement(el);
                el.removeAttribute('data-config-highlighted');
            });
            const currentFullUrl = window.location.href;
            const newChatUrl = prompt(
                'Step 3/3: Fill the New Chat URL.\n\n- You can paste the FULL URL (recommended)\n- Or just the path (like "/")',
                currentFullUrl
            );
            tempCustomConfig.newChatButton = newChatUrl !== null ? newChatUrl : '/';

            instructions.innerHTML = `
                <strong>Step 2/3:</strong> Send button selected ✓<br>
                <code>${tempCustomConfig.sendButton}</code><br><br>
                <strong>Step 3/3:</strong> New Chat URL set ✓<br>
                <code>${tempCustomConfig.newChatButton}</code><br><br>
                Configuration complete! Click "Save" to apply.
            `;

            nextBtn.textContent = 'Save';
            nextBtn.style.display = 'inline-block';
            customConfigStep = 3;
            break;
        case 2:
            isCustomConfigMode = false;
            document.removeEventListener('mouseover', handleConfigHover);
            document.removeEventListener('click', handleConfigClick, true);
            break;
    }
    document.querySelectorAll('[data-config-highlighted]').forEach(el => {
        unhighlightElement(el);
        el.removeAttribute('data-config-highlighted');
    });
}
function startCustomConfig() {
    isCustomConfigMode = true;
    customConfigStep = 0;
    tempCustomConfig = {};
    const extensionContainer = document.getElementById('deepseek-line-sender');
    if (extensionContainer) {
        extensionContainer.style.display = 'none';
    }

    const { overlay, instructions, nextBtn } = createCustomConfigOverlay();

    instructions.innerHTML = `
        <strong>Step 1/3:</strong> Click on the <strong>text input area</strong> where you normally type your prompts.<br><br>
        <em>Move your mouse around to see elements highlighted.</em>
    `;
    document.addEventListener('mouseover', handleConfigHover);
    document.addEventListener('click', handleConfigClick, true);
    nextBtn.onclick = async function () {
        if (customConfigStep === 3) {
            const hostname = window.location.hostname;
            const siteName = prompt('Enter a name for this AI site:', hostname) || hostname;

            customSelectors[hostname] = {
                name: siteName,
                textarea: tempCustomConfig.textarea,
                sendButton: tempCustomConfig.sendButton,
                newChatButton: tempCustomConfig.newChatButton,
                responseContainer: 'pre'
            };

            console.log('✅ Custom selector configuration complete for:', hostname);
            console.log('\n📋 Copy this code to add to customSelectors:\n');
            console.log(`    '${hostname}': {`);
            console.log(`        name: '${siteName}',`);
            console.log(`        whitelisted: true,`);
            console.log(`        newChatButton: '${tempCustomConfig.newChatButton}',`);
            console.log(`        responseContainer: 'pre',`);
            console.log(`        sendButton: '${tempCustomConfig.sendButton}',`);
            console.log(`        textarea: '${tempCustomConfig.textarea}'`);
            console.log(`    }`);
            console.log('\n🔍 Verification:');
            console.log('Textarea Element:', findElementByCustomSelector('textarea'));
            console.log('Send Button Element:', findElementByCustomSelector('sendButton'));

            await saveCustomSelectors();
            isCustomConfigMode = false;
            customConfigStep = 0;
            tempCustomConfig = {};
            document.body.removeChild(overlay);
            document.removeEventListener('mouseover', handleConfigHover);
            document.removeEventListener('click', handleConfigClick, true);
            const extensionContainer = document.getElementById('deepseek-line-sender');
            if (extensionContainer) {
                extensionContainer.style.display = 'block';
            }
            const status = document.querySelector('#deepseek-line-sender span');
            if (status) {
                status.textContent = `Custom configuration saved for ${siteName}!`;
                status.style.color = '#90EE90';
                setTimeout(() => {
                    status.textContent = '';
                    status.style.color = '#7fdfff';
                }, 3000);
            }
        }
    };
}
function searchPathInDivs() {
    const divs = document.querySelectorAll('div[class]:not([tabindex])');

    for (const div of divs) {
        const text = div.textContent || div.innerText || '';
        const pathMatch = text.match(/# PATH:\s*(.+)/);
        if (pathMatch) {
            const path = pathMatch[1].trim();
            if (path) {
                console.log('Auto-detected path from div:', path);
                return path;
            }
        }
    }
    return null;
}
function findElementByCustomSelector(selectorType) {
    const siteConfig = getCurrentSiteSelectors();
    if (!siteConfig || !siteConfig[selectorType]) {
        return null;
    }

    const selector = siteConfig[selectorType];

    if (selector.includes(':nth(')) {
        const match = selector.match(/(.+):nth\((\d+)\)$/);
        if (match) {
            const [, baseSelector, indexStr] = match;
            const index = parseInt(indexStr, 10);
            const elements = document.querySelectorAll(baseSelector);
            if (elements.length > index) {
                return elements[index];
            }
        }
        return null;
    }

    if (selector.includes(':contains(')) {
        const match = selector.match(/(.+):contains\("(.+)"\)/);
        if (match) {
            const [, elementSelector, text] = match;
            const elements = document.querySelectorAll(elementSelector);
            for (const element of elements) {
                if (element.textContent && element.textContent.trim().toLowerCase().includes(text.toLowerCase())) {
                    if (typeof element.click !== 'function') {
                        const clickableParent = element.closest('button, div, a, span, input');
                        if (clickableParent && typeof clickableParent.click === 'function') {
                            return clickableParent;
                        }
                    }
                    return element.closest('div') || element;
                }
            }
        }
        return null;
    }
    function parseSelector(sel) {
        const parsed = {
            tag: '',
            classes: [],
            attributes: {}
        };
        const tagMatch = sel.match(/^([a-zA-Z0-9-]+)/);
        if (tagMatch) {
            parsed.tag = tagMatch[1].toLowerCase();
        }
        const classMatches = sel.match(/\.([^.\[\s]+)/g);
        if (classMatches) {
            parsed.classes = classMatches.map(c => c.substring(1));
        }
        const attrMatches = sel.match(/\[([^\]]+)\]/g);
        if (attrMatches) {
            attrMatches.forEach(attr => {
                const cleanAttr = attr.slice(1, -1);
                if (cleanAttr.includes('=')) {
                    const [key, value] = cleanAttr.split('=');
                    parsed.attributes[key] = value.replace(/"/g, '');
                } else {
                    parsed.attributes[cleanAttr] = true;
                }
            });
        }

        return parsed;
    }
    function calculateMatches(element, parsed) {
        let matches = 0;
        let totalCriteria = 0;
        if (parsed.tag) {
            totalCriteria++;
            if (element.tagName.toLowerCase() === parsed.tag) {
                matches++;
            }
        }
        if (parsed.classes.length > 0) {
            totalCriteria += parsed.classes.length;
            parsed.classes.forEach(cls => {
                if (element.classList.contains(cls)) {
                    matches++;
                }
            });
        }
        Object.keys(parsed.attributes).forEach(attr => {
            totalCriteria++;
            if (parsed.attributes[attr] === true) {
                if (element.hasAttribute(attr)) {
                    matches++;
                }
            } else {
                if (element.getAttribute(attr) === parsed.attributes[attr]) {
                    matches++;
                }
            }
        });

        return { matches, totalCriteria, percentage: totalCriteria > 0 ? (matches / totalCriteria) * 100 : 0 };
    }
    function findBestMatch(selector) {
        const parsed = parseSelector(selector);
        console.log('Parsed selector:', parsed);
        try {
            const exactElement = document.querySelector(selector);
            if (exactElement) {
                console.log('Found exact match:', exactElement);
                return exactElement;
            }
        } catch (e) {
            console.log('Exact selector failed, using flexible matching');
        }
        let candidates = [];
        if (parsed.tag) {
            candidates = Array.from(document.querySelectorAll(parsed.tag));
        } else {
            candidates = Array.from(document.querySelectorAll('button, a, div, span, input'));
        }
        if (parsed.classes.length > 0) {
            parsed.classes.forEach(cls => {
                const classElements = Array.from(document.querySelectorAll(`.${cls}`));
                candidates = candidates.concat(classElements);
            });
        }
        candidates = [...new Set(candidates)];

        console.log(`Found ${candidates.length} candidates for matching`);

        let bestMatch = null;
        let bestScore = 0;

        candidates.forEach(element => {
            const score = calculateMatches(element, parsed);
            console.log('Element:', element, 'Score:', score);
            if (score.percentage > bestScore && score.percentage >= 30) {
                bestMatch = element;
                bestScore = score.percentage;
            }
        });

        console.log('Best match:', bestMatch, 'Score:', bestScore);
        return bestMatch;
    }
    if (selector.includes(',')) {
        const selectors = selector.split(',').map(s => s.trim());
        for (const sel of selectors) {
            const element = findBestMatch(sel);
            if (element) {
                if (typeof element.click !== 'function' && (selectorType === 'sendButton' || selectorType === 'newChatButton')) {
                    const clickableParent = element.closest('button, div, a, span, input');
                    if (clickableParent && typeof clickableParent.click === 'function') {
                        return clickableParent;
                    }
                } else if (typeof element.click === 'function') {
                    return element;
                }
            }
        }
        if (selectorType === 'newChatButton') {
            const fallbackElement = document.querySelector('a.new-chat-btn, [class*="new-chat-btn"], [class*="new-chat"]');
            if (fallbackElement) return fallbackElement;
        }
        return null;
    }

    const element = findBestMatch(selector);
    if (element) {
        if (typeof element.click !== 'function' && (selectorType === 'sendButton' || selectorType === 'newChatButton')) {
            const clickableParent = element.closest('button, div, a, span, input');
            if (clickableParent && typeof clickableParent.click === 'function') {
                console.log('Using clickable parent:', clickableParent);
                return clickableParent;
            }
            console.warn(`Element found but no clickable parent available for ${selectorType}:`, element);
            return null;
        }
        if ((selectorType === 'sendButton' || selectorType === 'newChatButton') && typeof element.click !== 'function') {
            console.warn(`Element found but click method not available for ${selectorType}:`, element);
            return null;
        }
        return element;
    }

    return null;
}



(function () {
    let textarea;
    let siteWhitelist = [];
    let isStopRequested = false;
    function getCleanText(el) {
        if (!el) return "";
        const text = el.innerText || el.textContent || "";
        return text
            .replace(/[\u200B-\u200D\uFEFF]/g, "")
            .replace(/\u00A0/g, " ");
    }
    async function loadWhitelist() {
        try {
            const result = await browserAPI.storage.local.get(['siteWhitelist', 'removedDefaultSites']);
            let userWhitelist = result.siteWhitelist || [];
            let removedSites = result.removedDefaultSites || [];

            const defaultWhitelisted = Object.keys(customSelectors)
                .filter(hostname => customSelectors[hostname].whitelisted && !removedSites.includes(hostname));

            siteWhitelist = [...new Set([...userWhitelist, ...defaultWhitelisted])];

            console.log('Loaded site whitelist:', siteWhitelist);
            console.log('Removed default sites:', removedSites);
            return siteWhitelist;
        } catch (error) {
            console.error('Error loading whitelist:', error);
            return [];
        }
    }
    function isCurrentSiteWhitelisted() {
        const hostname = window.location.hostname;
        return siteWhitelist.includes(hostname);
    }
    function hideExtensionMenu() {
        const wrapper = document.getElementById('deepseek-wrapper');
        if (wrapper) {
            wrapper.style.display = 'none';
        }
        window.deepseekInjected = false;
    }
    function showExtensionMenu() {
        const wrapper = document.getElementById('deepseek-wrapper');
        if (wrapper) {
            wrapper.style.display = 'block';
        }
    }
    browserAPI.runtime.onMessage.addListener((message, sender, sendResponse) => {
        if (message.type === 'WHITELIST_CHANGED') {
            console.log('Whitelist changed:', message);
            siteWhitelist = message.whitelist;
            const hostname = window.location.hostname;

            if (message.hostname === hostname) {
                if (message.isWhitelisted) {
                    if (!document.getElementById('deepseek-wrapper')) {
                        window.deepseekInjected = false;
                        waitForPromptAndInject();
                    } else {
                        showExtensionMenu();
                    }
                } else {
                    hideExtensionMenu();
                }
            }
            sendResponse({ success: true });
        }
        return true;
    });

    async function waitForPromptAndInject() {

        await loadCustomSelectors();
        await loadWhitelist();
        if (!isCurrentSiteWhitelisted()) {
            console.log('Site not whitelisted, menu will not be shown:', window.location.hostname);
            return;
        }

        const siteConfig = getCurrentSiteSelectors();
        if (window.deepseekInjected) return;
        window.deepseekInjected = true;
        const oldWrapper = document.getElementById('deepseek-wrapper');
        if (oldWrapper) oldWrapper.remove();
        const oldSender = document.getElementById('deepseek-line-sender');
        if (oldSender) oldSender.remove();
        await loadCustomSelectors();
        const wrapper = document.createElement('div');
        wrapper.id = 'deepseek-wrapper';
        wrapper.style = `
            position: fixed !important;
            top: 0 !important;
            left: 50% !important;
            transform: translateX(-50%) !important;
            z-index: 2147483647 !important;
            margin: 16px auto !important;
            pointer-events: auto !important;
        `;
        const hideBtn = document.createElement('button');
        hideBtn.id = 'deepseek-hide-btn';
        hideBtn.type = 'button';
        hideBtn.textContent = 'Hide';
        hideBtn.style = `
            display: block !important;
            margin: 0 auto 8px auto !important;
            padding: 4px 12px !important;
            background: #2a2929ff !important;
            color: white !important;
            border: 1px solid #555 !important;
            border-radius: 4px !important;
            cursor: pointer !important;
            font-size: 12px !important;
        `;
        wrapper.appendChild(hideBtn);
        const container = document.createElement('div');
        container.id = 'deepseek-line-sender';
        container.style = `
            padding: 12px !important;
            border: 1px solid #ccc !important;
            background: #2a2929ff !important;
            border-radius: 8px !important;
            min-width: 320px !important;
            max-width: 90vw !important;
            box-shadow: 0 2px 8px rgba(0,0,0,0.12) !important;
        `;
        container.tabIndex = -1;
        const siteInfo = document.createElement('div');
        siteInfo.style = `
            background: #1a1a1a !important;
            border: 1px solid #444 !important;
            border-radius: 4px !important;
            padding: 6px 8px !important;
            margin-bottom: 8px !important;
            font-size: 12px !important;
            color: #7fdfff !important;
            font-family: monospace !important;
        `;
        const hostname = window.location.hostname;
        const configStatus = siteConfig ? '✓ Configured' : '⚠️ Not configured';
        const siteName = siteConfig ? siteConfig.name : hostname;
        siteInfo.textContent = `${siteName} - ${configStatus}`;
        container.appendChild(siteInfo);
        const warningNotice = document.createElement('div');
        warningNotice.style = `
            background: #4a1a1a !important;
            border: 1px solid #7a3a3a !important;
            border-radius: 4px !important;
            padding: 6px 8px !important;
            margin-bottom: 8px !important;
            font-size: 11px !important;
            color: #ffbaba !important;
            text-align: center !important;
        `;
        warningNotice.textContent = '⚠️ Keep this tab active. Do not minimize or switch tabs during processing to avoid progress loss.';
        container.appendChild(warningNotice);
        const configContainer = document.createElement('div');
        configContainer.style = `
            display: flex !important;
            gap: 10px !important;
            margin-bottom: 8px !important;
            padding: 8px !important;
            background: #1a1a1a !important;
            border: 1px solid #444 !important;
            border-radius: 4px !important;
            align-items: center !important;
            justify-content: space-between !important;
        `;

        const createConfigInput = (label, id, defaultValue) => {
            const wrapper = document.createElement('div');
            wrapper.style = 'display: flex !important; align-items: center !important; gap: 5px !important;';

            const labelEl = document.createElement('label');
            labelEl.textContent = label;
            labelEl.style = 'color: #ccc !important; font-size: 11px !important; white-space: nowrap !important;';

            const input = document.createElement('input');
            input.id = id;
            input.type = 'number';
            input.value = defaultValue;
            input.style = `
                width: 50px !important;
                background: #333 !important;
                color: #fff !important;
                border: 1px solid #555 !important;
                border-radius: 3px !important;
                padding: 2px 4px !important;
                font-size: 11px !important;
            `;
            input.onchange = async () => {
                const val = parseInt(input.value, 10);
                if (!isNaN(val)) {
                    await browserAPI.storage.local.set({ [id]: val });
                }
            };

            wrapper.appendChild(labelEl);
            wrapper.appendChild(input);
            return wrapper;
        };

        const charInput = createConfigInput('Chars/Block:', 'maxCharsPerBlock', 3500);
        const blockInput = createConfigInput('Blocks/Chat:', 'blocksPerNewChat', 4);
        browserAPI.storage.local.get(['maxCharsPerBlock', 'blocksPerNewChat'], (result) => {
            if (result.maxCharsPerBlock) charInput.querySelector('input').value = result.maxCharsPerBlock;
            if (result.blocksPerNewChat) blockInput.querySelector('input').value = result.blocksPerNewChat;
        });

        configContainer.appendChild(charInput);
        configContainer.appendChild(blockInput);
        container.appendChild(configContainer);
        textarea = document.createElement('textarea');
        textarea.placeholder = 'Select a file on Resplitter and\npress Content Preview and Copy all Parts';
        textarea.rows = 8;
        textarea.style = 'width: 100% !important; margin-bottom: 8px !important; background-color: #3c3c3c !important; color: white !important; border: 1px solid #555 !important;';
        container.appendChild(textarea);
        const fileInfo = document.createElement('div');
        fileInfo.id = 'current-file-info';
        fileInfo.style = `
            background: #1a1a1a !important;
            border: 1px solid #444 !important;
            border-radius: 4px !important;
            padding: 6px 8px !important;
            margin-bottom: 8px !important;
            font-size: 12px !important;
            color: #7fdfff !important;
            font-family: monospace !important;
            white-space: nowrap !important;
            overflow: hidden !important;
            text-overflow: ellipsis !important;
        `;
        fileInfo.textContent = 'Copy the content from ReSplitter and paste it above';
        container.appendChild(fileInfo);
        textarea.addEventListener('input', () => {
            const firstLine = textarea.value.split('\n')[0].trim();
            if (firstLine.startsWith('# PATH:')) {
                const fullPath = firstLine.substring(7).trim();
                currentFilePath = fullPath;
                const normalizedPath = fullPath.replace(/\\/g, '/');
                const parts = normalizedPath.split('/').filter(p => p !== '');
                const lastItem = parts[parts.length - 1] || fullPath;
                const isFile = lastItem.includes('.') && !lastItem.endsWith('.');
                const label = isFile ? '📄' : '📁';

                fileInfo.textContent = `${label}: ${lastItem}`;
                fileInfo.title = fullPath;
                fileInfo.style.color = isFile ? '#ffda7f' : '#7fdfff';
            } else if (textarea.value.trim() === '') {
                currentFilePath = null;
                fileInfo.textContent = 'Copy the content from ReSplitter and paste it above';
                fileInfo.title = '';
                fileInfo.style.color = '#7fdfff';
            }
        });
        const startStyle = `
            margin-right: 8px !important;
            margin-bottom: 8px !important;
            padding: 6px 12px !important;
            background: #0c4aa7ff !important;
            color: white !important;
            border: 1px solid #003479ff !important;
            border-radius: 4px !important;
            cursor: pointer !important;
            font-size: 12px !important;
        `;
        const buttonStyle = `
            margin-right: 8px !important;
            margin-bottom: 8px !important;
            padding: 6px 12px !important;
            background: #555 !important;
            color: white !important;
            border: 1px solid #888 !important;
            border-radius: 4px !important;
            cursor: pointer !important;
            font-size: 12px !important;
        `;
        const sendBtn = document.createElement('button');
        sendBtn.type = 'button';
        sendBtn.textContent = 'Start';
        sendBtn.style = startStyle;
        container.appendChild(sendBtn);
        stopTasksBtn = document.createElement('button');
        stopTasksBtn.type = 'button';
        stopTasksBtn.textContent = 'Stop Tasks';
        stopTasksBtn.style = buttonStyle;
        container.appendChild(stopTasksBtn);
        const downloadIdsBtn = document.createElement('button');
        downloadIdsBtn.type = 'button';
        downloadIdsBtn.textContent = 'Copy Results';
        downloadIdsBtn.style = buttonStyle;
        container.appendChild(downloadIdsBtn);
        const addCustomBtn = document.createElement('button');
        addCustomBtn.type = 'button';
        addCustomBtn.textContent = 'Setup this Site';
        addCustomBtn.style = `
            margin: 4px !important;
            padding: 4px 8px !important;
            background: #4a9eff !important;
            color: white !important;
            border: 1px solid #888 !important;
            border-radius: 4px !important;
            cursor: pointer !important;
            font-size: 12px !important;
        `;
        addCustomBtn.onclick = function () {
            startCustomConfig();
        };
        container.appendChild(addCustomBtn);
        const clearStorageBtn = document.createElement('button');
        clearStorageBtn.type = 'button';
        clearStorageBtn.textContent = 'Clear Storage';
        clearStorageBtn.style = `
            margin: 4px !important;
            padding: 4px 8px !important;
            background: #ff6b6b !important;
            color: white !important;
            border: 1px solid #888 !important;
            border-radius: 4px !important;
            cursor: pointer !important;
            font-size: 12px !important;
        `;
        clearStorageBtn.onclick = async function () {
            if (confirm('Clear all captured results and saved progress?')) {
                await clearProcessState();
                status.textContent = 'Storage cleared.';
                status.style.color = '#ff6b6b';
            }
        };
        container.appendChild(clearStorageBtn);
        const status = document.createElement('span');
        status.style = 'margin-left: 8px !important; color: #7fdfff !important;';
        container.appendChild(status);
        stopTasksBtn.onclick = async function () {
            isStopRequested = true;
            for (const interval of runningIntervals) {
                clearInterval(interval);
            }
            runningIntervals = [];
            for (const timeout of runningTimeouts) {
                clearTimeout(timeout);
            }
            runningTimeouts = [];
            currentFilePath = null;
            await clearProcessState();
            const fileInfo = document.getElementById('current-file-info');
            if (fileInfo) {
                fileInfo.textContent = 'Tasks stopped manually. Progress cleared.';
                fileInfo.style.color = '#7fdfff';
                fileInfo.title = '';
            }
            status.textContent = 'Tasks stopped manually.';
            status.style.color = '#ff6b6b';
        };
        downloadIdsBtn.onclick = async function () {
            const allLines = getAllPreIds();
            if (allLines.length === 0) {
                status.textContent = 'No sentences found.';
                status.style.color = '#7fdfff';
                return;
            }
            try {
                await navigator.clipboard.writeText(allLines.join('\n'));
                status.textContent = 'IDs copied to clipboard.';
                status.style.color = '#7fdfff';
            } catch (err) {
                status.textContent = 'Error copying to clipboard.';
                status.style.color = '#7fdfff';
            }
        };
        function getAllPreIds() {
            const siteConfig = getCurrentSiteSelectors();
            const hostname = window.location.hostname;
            if (hostname === 'chat.qwen.ai') {
                const lineDivs = document.querySelectorAll('div.cm-line');
                let allLines = [];
                let seen = new Set();
                for (const div of lineDivs) {
                    const lineText = getCleanText(div).trim();
                    if (lineText) {
                        const line = lineText;
                        const idMatch = line.match(/^(\d+)\|/);
                        if (idMatch && !seen.has(idMatch[1])) {
                            seen.add(idMatch[1]);
                            allLines.push(line);
                        }
                    }
                }
                return allLines;
            }
            const responseSelector = siteConfig ? siteConfig.responseContainer : 'pre';
            const preList = Array.from(document.querySelectorAll(responseSelector));
            let allLines = [];
            let seen = new Set();
            for (const pre of preList) {
                const text = getCleanText(pre);
                if (text) {
                    const lines = parsePreResults(text);
                    for (let line of lines) {
                        let idMatch = line.match(/^(\d+)\|/);
                        if (idMatch && !seen.has(idMatch[1])) {
                            seen.add(idMatch[1]);
                            allLines.push(line);
                        }
                    }
                }
            }
            return allLines;
        }
        wrapper.appendChild(container);
        document.body.appendChild(wrapper);
        let isHidden = false;
        hideBtn.onclick = function () {
            isHidden = !isHidden;
            if (isHidden) {
                container.style.display = 'none';
                hideBtn.textContent = 'Show';
                hideBtn.style.background = '#4a4a4a !important';
            } else {
                container.style.display = 'block';
                hideBtn.textContent = 'Hide';
                hideBtn.style.background = '#2a2929ff';
            }
        };
        sendBtn.onclick = async function (e, resumeIndex = 0, resumeState = null) {
            isStopRequested = false;
            const siteConfig = getCurrentSiteSelectors();
            if (!siteConfig) {
                status.textContent = 'Site not configured. Use "Add Custom" button first.';
                status.style.color = '#ff6b6b';
                setTimeout(() => {
                    status.style.color = '#7fdfff';
                    status.textContent = '';
                }, 5000);
                return;
            }
            const hostname = window.location.hostname;
            let existingResponseElements;
            if (hostname === 'chat.qwen.ai') {
                existingResponseElements = document.querySelectorAll('div.cm-line');
            } else {
                const responseSelector = siteConfig.responseContainer;
                existingResponseElements = document.querySelectorAll(responseSelector);
            }

            if (existingResponseElements.length > 0) {
                status.textContent = 'Previous results found. Please start a new chat to avoid conflicts.';
                status.style.color = '#ff6b6b';
                setTimeout(() => {
                    status.style.color = '';
                    status.textContent = '';
                }, 5000);
                return;
            }

            status.textContent = 'Processing...';
            status.style.color = '#7fdfff';
            const lines = textarea.value.split('\n').filter(l => l.trim());
            let pathLine = '';
            let startIndex = 0;
            if (lines.length > 0 && lines[0].trim().startsWith('# PATH:')) {
                pathLine = lines[0].trim();
                startIndex = 1;
            }
            let promptStart = lines.findIndex((l, idx) => idx >= startIndex && l.trim() === '-----#PROMPT#-----');
            let promptEnd = -1;
            let userPrompt = '';
            if (promptStart !== -1) {
                promptEnd = lines.findIndex((l, idx) => idx > promptStart && l.trim() === '-----#PROMPT#-----');
                if (promptEnd !== -1) {
                    userPrompt = lines.slice(promptStart + 1, promptEnd).join('\n');
                    userPrompt += "\n - Ensure to return the content bracketed by ```";
                }
            }
            if (pathLine) {
                userPrompt = pathLine + (userPrompt ? '\n' + userPrompt : '');
            }
            let idsLines = lines.filter((l, idx) => {
                if (idx < startIndex) {
                    return false;
                }
                if (promptEnd === -1 || idx > promptEnd) {
                    return /^\d+\|/.test(l.trim());
                }
                return false;
            });
            const maxChars = parseInt(document.getElementById('maxCharsPerBlock')?.value || '1000', 10);
            const blocksPerChat = parseInt(document.getElementById('blocksPerNewChat')?.value || '2', 10);
            let blocks = [];
            let currentBlock = [];
            let currentLength = 0;
            for (let i = 0; i < idsLines.length; i++) {
                const line = idsLines[i];
                if (currentLength + line.length + 1 > maxChars && currentBlock.length > 0) {
                    blocks.push(currentBlock);
                    currentBlock = [];
                    currentLength = 0;
                }
                currentBlock.push(line);
                currentLength += line.length + 1;
            }
            if (currentBlock.length > 0) {
                blocks.push(currentBlock);
            }
            if (resumeState && resumeState.blocks && resumeState.blocks.length > 0) {
                blocks = resumeState.blocks;
                console.log('Resuming with saved blocks:', blocks.length, 'blocks, starting from index', resumeIndex);
            }

            let allResults = resumeState ? resumeState.results : [];
            let seenIds = resumeState ? new Set(resumeState.seenIds) : new Set();
            let totalFoundIdsCount = resumeState ? resumeState.totalFoundIdsCount : 0;
            if (resumeState) {
                userPrompt = resumeState.userPrompt;
                pathLine = resumeState.pathLine;
            }
            let lastId = null;
            for (let i = lines.length - 1; i >= startIndex; i--) {
                const match = lines[i].match(/^(\d+)\|/);
                if (match) {
                    lastId = match[1];
                    break;
                }
            }
            for (let blockIdx = resumeIndex; blockIdx < blocks.length; blockIdx++) {
                const block = blocks[blockIdx];
                let blockLastId = null;
                for (let i = block.length - 1; i >= 0; i--) {
                    const match = block[i].match(/^(\d+)\|/);
                    if (match) {
                        blockLastId = match[1];
                        break;
                    }
                }
                const isLastBlock = (blockIdx === blocks.length - 1);
                const willOpenNewChat = (blockIdx + 1) % blocksPerChat === 0 && blockIdx < blocks.length - 1;

                if (isStopRequested) return;

                if (blockLastId) {
                    status.textContent = `Waiting until ID: ${blockLastId}...`;
                }
                const promptBox = findElementByCustomSelector('textarea');
                if (!promptBox) {
                    status.textContent = 'Textarea not found.';
                    status.style.color = '#ff6b6b';
                    return;
                }
                const isContentEditable = promptBox.getAttribute('contenteditable') === 'true' || promptBox.hasAttribute('contenteditable');

                console.log('PromptBox element:', promptBox);
                console.log('Is contenteditable:', isContentEditable);
                console.log('Element tagName:', promptBox.tagName);
                let msg = '';
                if (userPrompt) {
                    msg += userPrompt + '\n';
                }
                msg += block.join('\n');

                console.log('Message to insert:', msg.substring(0, 100) + '...');
                promptBox.focus();
                await new Promise(res => setTimeout(res, 200));

                if (isContentEditable) {
                    promptBox.innerHTML = '';
                    promptBox.focus();
                    try {
                        document.execCommand('selectAll', false, null);
                        document.execCommand('delete', false, null);
                        document.execCommand('insertText', false, msg);
                    } catch (e) {
                        console.log('execCommand failed, trying alternative methods');
                    }
                    if (!promptBox.textContent || promptBox.textContent.trim() === '') {
                        promptBox.textContent = msg;
                        promptBox.dispatchEvent(new InputEvent('beforeinput', {
                            bubbles: true,
                            cancelable: true,
                            inputType: 'insertText',
                            data: msg
                        }));

                        promptBox.dispatchEvent(new InputEvent('input', {
                            bubbles: true,
                            cancelable: false,
                            inputType: 'insertText',
                            data: msg
                        }));
                        promptBox.dispatchEvent(new Event('change', { bubbles: true }));
                        promptBox.dispatchEvent(new CompositionEvent('compositionstart', { bubbles: true }));
                        promptBox.dispatchEvent(new CompositionEvent('compositionupdate', { bubbles: true, data: msg }));
                        promptBox.dispatchEvent(new CompositionEvent('compositionend', { bubbles: true, data: msg }));
                    }

                    console.log('Inserted into contenteditable, textContent now:', (promptBox.textContent || '').substring(0, 100) + '...');
                } else {
                    promptBox.value = '';
                    promptBox.value = msg;
                    console.log('Inserted into textarea, value now:', (promptBox.value || '').substring(0, 100) + '...');
                    promptBox.dispatchEvent(new Event('input', { bubbles: true }));
                    promptBox.dispatchEvent(new Event('change', { bubbles: true }));
                }

                await new Promise(res => setTimeout(res, 300));
                let sent = false;
                let attempts = 0;
                const maxAttempts = 5;

                while (!sent && attempts < maxAttempts) {
                    if (isStopRequested) return;
                    attempts++;
                    status.textContent = `Sending block ${blockIdx + 1}/${blocks.length} (attempt ${attempts})...`;
                    let sendButton = findElementByCustomSelector('sendButton');

                    if (sendButton) {
                        sendButton.click();
                        await new Promise(res => setTimeout(res, Math.floor(Math.random() * (1385 - 1200 + 1)) + 1200));
                    } else {
                        promptBox.focus();
                        if (isContentEditable) {
                            const selection = window.getSelection();
                            const range = document.createRange();
                            range.selectNodeContents(promptBox);
                            range.collapse(false);
                            selection.removeAllRanges();
                            selection.addRange(range);
                        } else {
                            promptBox.select();
                        }

                        const enterEvent = new KeyboardEvent('keydown', {
                            bubbles: true,
                            cancelable: true,
                            key: 'Enter',
                            code: 'Enter',
                            which: 13,
                            keyCode: 13
                        });
                        promptBox.dispatchEvent(enterEvent);
                        await new Promise(res => setTimeout(res, Math.floor(Math.random() * (1385 - 1200 + 1)) + 1200));
                    }
                    await new Promise(res => setTimeout(res, 500));
                    const sitePromptBox = findElementByCustomSelector('textarea');
                    if (!sitePromptBox) {
                        console.warn('Site textarea not found for verification');
                        sent = false;
                    } else {
                        const isContentEditable = sitePromptBox.getAttribute('contenteditable') === 'true' || sitePromptBox.hasAttribute('contenteditable');
                        let currentValue;

                        if (isContentEditable) {
                            currentValue = (sitePromptBox.textContent || sitePromptBox.innerText || '').trim();
                        } else {
                            currentValue = sitePromptBox.value.trim();
                        }

                        const placeholder = sitePromptBox.placeholder || '';
                        if (currentValue === '' || currentValue === placeholder) {
                            sent = true;
                            status.textContent = `Block ${blockIdx + 1}/${blocks.length} sent.`;
                        } else {
                            await new Promise(res => setTimeout(res, Math.floor(Math.random() * (2000 - 1500 + 1)) + 1500));
                            let finalValue;
                            if (isContentEditable) {
                                finalValue = (sitePromptBox.textContent || sitePromptBox.innerText || '').trim();
                            } else {
                                finalValue = sitePromptBox.value.trim();
                            }

                            if (finalValue === '' || finalValue === placeholder) {
                                sent = true;
                                status.textContent = `Block ${blockIdx + 1}/${blocks.length} sent.`;
                            } else {
                                console.log(`Attempt ${attempts}: Site textarea not empty:`, finalValue.substring(0, 50) + '...');
                            }
                        }
                    }
                }

                if (isStopRequested) return;

                if (!sent) {
                    status.textContent = `Error: Block ${blockIdx + 1}/${blocks.length} after ${maxAttempts} attempts.`;
                    status.style.color = '#ff6b6b';
                    return;
                }
                if (blockLastId) {
                    let lastDetectedId = totalFoundIdsCount;
                    let lastIdChangeTime = Date.now();
                    let stallTimeoutTriggered = false;
                    const STALL_TIMEOUT_MS = 60000;

                    const countInterval = setInterval(() => {
                        if (isStopRequested) return;

                        const hostname = window.location.hostname;
                        let maxId = 0;

                        if (hostname === 'chat.qwen.ai') {
                            const lineDivs = document.querySelectorAll('div.cm-line');
                            for (const div of lineDivs) {
                                const lineText = getCleanText(div).trim();
                                if (lineText) {
                                    const line = lineText;
                                    const idMatch = line.match(/^(\d+)\|/);
                                    if (idMatch) {
                                        let idNum = parseInt(idMatch[1], 10);
                                        if (idNum > maxId) maxId = idNum;
                                    }
                                }
                            }
                        } else {
                            const responseSelector = siteConfig.responseContainer;
                            const preList = Array.from(document.querySelectorAll(responseSelector));
                            for (const pre of preList) {
                                const text = getCleanText(pre);
                                if (text) {
                                    const lines = parsePreResults(text);
                                    for (let line of lines) {
                                        let idMatch = line.match(/^(\d+)\|/);
                                        if (idMatch) {
                                            let idNum = parseInt(idMatch[1], 10);
                                            if (idNum > maxId) maxId = idNum;
                                        }
                                    }
                                }
                            }
                        }
                        if (maxId > 0) {
                            if (maxId > lastDetectedId) {
                                lastDetectedId = maxId;
                                lastIdChangeTime = Date.now();
                            }
                            totalFoundIdsCount = maxId;
                        }
                        const timeSinceLastChange = Date.now() - lastIdChangeTime;
                        if (timeSinceLastChange >= STALL_TIMEOUT_MS && !stallTimeoutTriggered) {
                            stallTimeoutTriggered = true;
                            status.textContent = `Timeout! No progress for 35s. Retrying block ${blockIdx + 1}...`;
                            status.style.color = '#ff6b6b';
                        }
                        if (!stallTimeoutTriggered) {
                            const remainingTime = Math.max(0, Math.ceil((STALL_TIMEOUT_MS - timeSinceLastChange) / 1000));
                            status.textContent = `ID: ${totalFoundIdsCount}/${blockLastId} (Block ${blockIdx + 1}/${blocks.length}) [Timeout: ${remainingTime}s]`;
                        }

                    }, 1000);
                    runningIntervals.push(countInterval);
                    const waitResult = await waitForLastIdInPreWithTimeout(blockLastId, block.length, () => stallTimeoutTriggered);

                    clearInterval(countInterval);
                    if (waitResult === 'timeout' || stallTimeoutTriggered) {
                        status.textContent = `Stall detected at block ${blockIdx + 1}. Opening new chat to retry...`;
                        status.style.color = '#ff6b6b';
                        await saveProcessState({
                            active: true,
                            blocks: blocks,
                            currentBlockIdx: blockIdx - 1,
                            results: allResults,
                            seenIds: Array.from(seenIds),
                            userPrompt: userPrompt,
                            pathLine: pathLine,
                            totalFoundIdsCount: totalFoundIdsCount,
                            maxChars: maxChars,
                            blocksPerChat: blocksPerChat
                        });
                        const newChatConfig = (siteConfig && siteConfig.newChatButton) ? siteConfig.newChatButton : '/';
                        if (typeof newChatConfig === 'string' && (newChatConfig.startsWith('/') || newChatConfig.toLowerCase().startsWith('http'))) {
                            if (newChatConfig.toLowerCase().startsWith('http')) {
                                window.location.href = newChatConfig;
                            } else {
                                history.pushState(null, '', newChatConfig);
                                window.dispatchEvent(new PopStateEvent('popstate', { state: null }));
                            }
                        }
                        return;
                    }

                    await new Promise(res => setTimeout(res, 3500));
                    const hostname = window.location.hostname;
                    if (hostname === 'chat.qwen.ai') {
                        const lineDivs = document.querySelectorAll('div.cm-line');
                        for (const div of lineDivs) {
                            const lineText = getCleanText(div).trim();
                            if (lineText) {
                                const line = lineText;
                                const idMatch = line.match(/^(\d+)\|/);
                                if (idMatch && !seenIds.has(idMatch[1])) {
                                    seenIds.add(idMatch[1]);
                                    allResults.push(line);
                                }
                            }
                        }
                    } else {
                        const responseSelector = siteConfig.responseContainer;
                        let preList = Array.from(document.querySelectorAll(responseSelector));
                        for (const pre of preList) {
                            const text = getCleanText(pre);
                            if (text) {
                                let lines = parsePreResults(text);
                                for (let line of lines) {
                                    let idMatch = line.match(/^(\d+)\|/);
                                    if (idMatch && !seenIds.has(idMatch[1])) {
                                        seenIds.add(idMatch[1]);
                                        allResults.push(line);
                                    }
                                }
                            }
                        }
                    }
                    await saveProcessState({
                        active: true,
                        blocks: blocks,
                        currentBlockIdx: blockIdx,
                        results: allResults,
                        seenIds: Array.from(seenIds),
                        userPrompt: userPrompt,
                        pathLine: pathLine,
                        totalFoundIdsCount: totalFoundIdsCount,
                        maxChars: maxChars,
                        blocksPerChat: blocksPerChat
                    });
                    if (isStopRequested) return;
                }



                if (willOpenNewChat) {
                    const siteConfig = getCurrentSiteSelectors();
                    const newChatConfig = (siteConfig && siteConfig.newChatButton) ? siteConfig.newChatButton : '/';
                    if (typeof newChatConfig === 'string' && (newChatConfig.startsWith('/') || newChatConfig.toLowerCase().startsWith('http'))) {
                        try {
                            if (newChatConfig.toLowerCase().startsWith('http')) {
                                window.location.href = newChatConfig;
                            } else {
                                history.pushState(null, '', newChatConfig);
                                window.dispatchEvent(new PopStateEvent('popstate', { state: null }));
                            }
                            status.textContent = 'Started new chat.';
                            status.style.color = '#7fdfff';
                            await new Promise(res => setTimeout(res, 2500));
                            if (isStopRequested) return;
                        } catch (e) {
                            status.textContent = 'Navigation failed.';
                            status.style.color = '#ff6b6b';
                            await new Promise(res => setTimeout(res, 1500));
                        }
                    } else {
                        const newChatButton = findElementByCustomSelector('newChatButton');
                        if (newChatButton) {
                            newChatButton.click();
                            status.textContent = 'Started new chat (click).';
                            status.style.color = '#7fdfff';
                            await new Promise(res => setTimeout(res, 2000));
                        } else {
                            console.warn('New Chat button selector failed, falling back to SPA mode with "/"');
                            try {
                                history.pushState(null, '', '/');
                                window.dispatchEvent(new PopStateEvent('popstate', { state: null }));
                                status.textContent = 'Started new chat (SPA Fallback).';
                                status.style.color = '#7fdfff';
                                await new Promise(res => setTimeout(res, 2000));
                            } catch (e) {
                                status.textContent = 'New Chat button not found and SPA fallback failed.';
                                status.style.color = '#ff6b6b';
                                await new Promise(res => setTimeout(res, 1500));
                            }
                        }
                    }
                }
            }
            if (allResults.length > 0) {
                const now = new Date();
                const h = String(now.getHours()).padStart(2, '0');
                const m = String(now.getMinutes()).padStart(2, '0');
                const filename = `content_${h}-${m}.txt`;
                const blob = new Blob([allResults.join('\n')], { type: 'text/plain' });
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.style.display = 'none';
                a.href = url;
                a.download = filename;
                document.body.appendChild(a);
                a.click();
                window.URL.revokeObjectURL(url);
                document.body.removeChild(a);
            }
            await clearProcessState();

            status.textContent = 'Done, press the Copy Results button.';
            status.style.color = '#7fdfff';
        };
        const savedState = await getProcessState();
        if (savedState && savedState.active && savedState.blocks && savedState.blocks.length > 0) {
            status.textContent = 'Detected active process, resuming in 3 seconds...';
            status.style.color = '#7fdfff';
            setTimeout(async () => {
                if (document.getElementById('maxCharsPerBlock')) document.getElementById('maxCharsPerBlock').value = savedState.maxChars;
                if (document.getElementById('blocksPerNewChat')) document.getElementById('blocksPerNewChat').value = savedState.blocksPerChat;
                sendBtn.onclick(null, savedState.currentBlockIdx + 1, savedState);
            }, 3000);
        }
    }
    function initializeExtension() {
        const oldWrapper = document.getElementById('deepseek-wrapper');
        if (oldWrapper) oldWrapper.remove();
        const oldSender = document.getElementById('deepseek-line-sender');
        if (oldSender) oldSender.remove();
        waitForPromptAndInject();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function () {
            if (!document.getElementById('deepseek-line-sender')) {
                initializeExtension();
            }
        });
    } else {
        if (!document.getElementById('deepseek-line-sender')) {
            initializeExtension();
        }
    }

    let lastUrl = location.href;
    new MutationObserver(() => {
        const url = location.href;
        if (url !== lastUrl) {
            lastUrl = url;
            setTimeout(() => {
                if (!document.getElementById('deepseek-line-sender')) {
                    initializeExtension();
                }
            }, 1000);
        }
    }).observe(document, { subtree: true, childList: true });

    function waitForLastIdInPre(lastId, expectedLinesCount) {
        return new Promise((resolve) => {
            function check() {
                if (isStopRequested) {
                    resolve(false);
                    return;
                }
                const siteConfig = getCurrentSiteSelectors();
                const hostname = window.location.hostname;

                if (hostname === 'chat.qwen.ai') {
                    const lineDivs = document.querySelectorAll('div.cm-line');
                    let foundLinesCount = 0;
                    let lastIdFound = false;
                    for (const div of lineDivs) {
                        const lineText = getCleanText(div).trim();
                        if (lineText) {
                            const line = lineText;
                            if (/^\d+\|/.test(line)) {
                                foundLinesCount++;
                            }
                            if (line.startsWith(lastId + '|')) {
                                lastIdFound = true;
                            }
                        }
                    }
                    if (lastIdFound && foundLinesCount >= expectedLinesCount) {
                        resolve(true);
                        return;
                    }
                } else {
                    const responseSelector = siteConfig ? siteConfig.responseContainer : 'pre';
                    const preList = Array.from(document.querySelectorAll(responseSelector));
                    for (const pre of preList) {
                        const text = getCleanText(pre);
                        if (text && (text.includes(lastId + '|') || text.match(new RegExp('^' + lastId + '\\|', 'm')))) {
                            const lines = parsePreResults(text);
                            if (lines.length >= expectedLinesCount) {
                                resolve(pre);
                                return;
                            }
                        }
                    }
                }
                const timeoutId = setTimeout(check, 4000);
                runningTimeouts.push(timeoutId);
            }
            check();
        });
    }
    function waitForLastIdInPreWithTimeout(lastId, expectedLinesCount, isTimeoutFn) {
        return new Promise((resolve) => {
            function check() {
                if (isStopRequested) {
                    resolve(false);
                    return;
                }
                if (isTimeoutFn && isTimeoutFn()) {
                    resolve('timeout');
                    return;
                }

                const siteConfig = getCurrentSiteSelectors();
                const hostname = window.location.hostname;

                if (hostname === 'chat.qwen.ai') {
                    const lineDivs = document.querySelectorAll('div.cm-line');
                    let foundLinesCount = 0;
                    let lastIdFound = false;
                    for (const div of lineDivs) {
                        const lineText = getCleanText(div).trim();
                        if (lineText) {
                            const line = lineText;
                            if (/^\d+\|/.test(line)) {
                                foundLinesCount++;
                            }
                            if (line.startsWith(lastId + '|')) {
                                lastIdFound = true;
                            }
                        }
                    }
                    if (lastIdFound && foundLinesCount >= expectedLinesCount) {
                        resolve(true);
                        return;
                    }
                } else {
                    const responseSelector = siteConfig ? siteConfig.responseContainer : 'pre';
                    const preList = Array.from(document.querySelectorAll(responseSelector));
                    for (const pre of preList) {
                        const text = getCleanText(pre);
                        if (text && (text.includes(lastId + '|') || text.match(new RegExp('^' + lastId + '\\|', 'm')))) {
                            const lines = parsePreResults(text);
                            if (lines.length >= expectedLinesCount) {
                                resolve(pre);
                                return;
                            }
                        }
                    }
                }
                const timeoutId = setTimeout(check, 2000);
                runningTimeouts.push(timeoutId);
            }
            check();
        });
    }

    function parsePreResults(text) {
        if (!text) return [];
        const cleanText = text
            .replace(/[\u200B-\u200D\uFEFF]/g, "")
            .replace(/\u00A0/g, " ");
        return cleanText.split('\n').filter(l => /^\d+\|/.test(l.trim()));
    }

    window.receiveIds = function (data) {
        console.log('receiveIds called with data:', data);
        let idsText, filePath;
        if (typeof data === 'string') {
            idsText = data;
            filePath = null;
            console.log('Processing string data, length:', idsText.length);
        } else if (typeof data === 'object' && data !== null) {
            idsText = data.content || '';
            filePath = data.file_path || null;
            console.log('Processing object data, content length:', idsText.length, 'file_path:', filePath);
        } else {
            console.error('Formato de datos no reconocido:', data);
            return;
        }

        currentFilePath = filePath;
        const fileInfo = document.getElementById('current-file-info');
        if (fileInfo) {
            if (filePath) {
                let displayText;
                const fileName = filePath.split(/[\\\/]/).pop() || filePath;
                if (filePath.toLowerCase().endsWith('.yml') || filePath.toLowerCase().endsWith('.yaml')) {
                    displayText = `📄 ${fileName}`;
                } else {
                    displayText = `📁 ${fileName}`;
                }
                fileInfo.textContent = displayText;
                fileInfo.style.color = '#9acd32';
                fileInfo.title = filePath;
            } else {
                fileInfo.textContent = 'Copy the content from ReSplitter and paste it above.';
                fileInfo.style.color = '#ccc';
                fileInfo.title = '';
            }
        }

        let attempts = 0;
        const maxAttempts = 50;
        const retryInterval = 500;
        console.log('Starting attemptInsertText with data length:', idsText.length);
        function attemptInsertText() {
            attempts++;
            console.log('attemptInsertText attempt', attempts, '/', maxAttempts);
            console.log(`Attempt ${attempts} to insert text...`);
            const container = document.getElementById('deepseek-line-sender');
            if (!container) {
                console.log('Container not found, retrying...');
                if (attempts < maxAttempts) {
                    setTimeout(attemptInsertText, retryInterval);
                }
                return;
            }
            const interfaceTextarea = container.querySelector('textarea');
            if (!interfaceTextarea) {
                console.log('Textarea not found, retrying...');
                if (attempts < maxAttempts) {
                    setTimeout(attemptInsertText, retryInterval);
                }
                return;
            }
            try {
                console.log('Inserting text into textarea, length:', idsText.length);
                interfaceTextarea.value = idsText;
                interfaceTextarea.focus();
                interfaceTextarea.dispatchEvent(new Event('input', { bubbles: true }));
                interfaceTextarea.dispatchEvent(new Event('change', { bubbles: true }));
                console.log('Text inserted successfully, textarea value length:', interfaceTextarea.value.length);
            } catch (error) {
                console.warn('Error insertando texto en textarea:', error);
            }
            setTimeout(() => {
                console.log('Checking if insertion was successful...', 'Expected:', idsText.trim().length, 'Actual:', interfaceTextarea.value.trim().length);
                if (interfaceTextarea.value.trim() === idsText.trim()) {
                    return;
                } else {
                    if (attempts < maxAttempts) {
                        setTimeout(attemptInsertText, retryInterval);
                    }
                }
            }, 100);
        }
        attemptInsertText();
    };
})();