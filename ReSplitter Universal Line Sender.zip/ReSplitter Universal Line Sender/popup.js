// Popup script for ReSplitter Universal

const browserAPI = chrome;

// DOM elements
const siteInfoEl = document.getElementById('siteInfo');
const whitelistBtn = document.getElementById('whitelistBtn');
const btnTextEl = document.getElementById('btnText');
const statusTextEl = document.getElementById('statusText');

let currentHostname = null;
let whitelist = [];
// Default customSelectors (same as in content.js)
let customSelectors = {
    'www.kimi.com': {
        name: 'www.kimi.com',
        whitelisted: true,
        newChatButton: '/',
        responseContainer: 'pre',
        sendButton: 'div.send-button',
        textarea: 'div.chat-input-editor[role="textbox"]'
    },
    'aistudio.google.com': {
        name: 'Google AI Studio',
        whitelisted: true,
        newChatButton: 'https://aistudio.google.com/app/prompts/new_chat',
        responseContainer: 'pre',
        sendButton: 'button.ms-button-primary[aria-label*="Run"], button[type="submit"].ms-button-primary',
        textarea: 'textarea[formcontrolname="promptText"], textarea[aria-label="Enter a prompt"]'
    },
    'chat.deepseek.com': {
        name: 'DeepSeek Chat',
        whitelisted: true,
        newChatButton: 'https://chat.deepseek.com/',
        responseContainer: 'pre',
        sendButton: 'div.ds-icon-button > div.ds-icon-button__hover-bg:nth-of-type(1):nth(6)',
        textarea: 'textarea[placeholder="Message DeepSeek"]'
    }
};
let removedDefaultSites = [];

// Initialize popup
async function init() {
    // Get current tab
    const tabs = await browserAPI.tabs.query({ active: true, currentWindow: true });

    if (tabs.length === 0) {
        siteInfoEl.textContent = 'No active tab';
        whitelistBtn.disabled = true;
        return;
    }

    const tab = tabs[0];

    try {
        const url = new URL(tab.url);
        currentHostname = url.hostname;
        siteInfoEl.textContent = currentHostname;
    } catch (e) {
        siteInfoEl.textContent = 'Invalid URL';
        whitelistBtn.disabled = true;
        return;
    }

    // Check if this is a restricted URL (chrome://, edge://, etc.)
    if (tab.url.startsWith('chrome://') ||
        tab.url.startsWith('edge://') ||
        tab.url.startsWith('about:') ||
        tab.url.startsWith('chrome-extension://')) {
        siteInfoEl.textContent = 'Cannot whitelist this page';
        whitelistBtn.disabled = true;
        whitelistBtn.style.opacity = '0.5';
        whitelistBtn.style.cursor = 'not-allowed';
        return;
    }

    // Load customSelectors and whitelist from storage
    await loadCustomSelectors();
    await loadWhitelist();
    updateUI();
}

// Load customSelectors from chrome.storage
async function loadCustomSelectors() {
    try {
        const result = await browserAPI.storage.local.get(['customSelectors']);
        if (result.customSelectors) {
            // Merge stored selectors with default ones (stored ones override defaults)
            customSelectors = { ...customSelectors, ...result.customSelectors };
            console.log('Loaded customSelectors:', customSelectors);
        }
    } catch (error) {
        console.error('Error loading customSelectors:', error);
    }
}

// Load whitelist from chrome.storage
async function loadWhitelist() {
    try {
        const result = await browserAPI.storage.local.get(['siteWhitelist', 'removedDefaultSites']);
        let userWhitelist = result.siteWhitelist || [];
        removedDefaultSites = result.removedDefaultSites || [];

        // Add default whitelisted sites from customSelectors
        const defaultWhitelisted = Object.keys(customSelectors)
            .filter(hostname => customSelectors[hostname].whitelisted && !removedDefaultSites.includes(hostname));

        // Merge user whitelist with default whitelisted sites (avoiding duplicates)
        whitelist = [...new Set([...userWhitelist, ...defaultWhitelisted])];

        console.log('Loaded whitelist:', whitelist);
        console.log('Removed default sites:', removedDefaultSites);
    } catch (error) {
        console.error('Error loading whitelist:', error);
        whitelist = [];
    }
}

// Save whitelist to chrome.storage
async function saveWhitelist() {
    try {
        await browserAPI.storage.local.set({ siteWhitelist: whitelist });
        console.log('Saved whitelist:', whitelist);
    } catch (error) {
        console.error('Error saving whitelist:', error);
    }
}

// Save removed default sites to chrome.storage
async function saveRemovedDefaultSites() {
    try {
        await browserAPI.storage.local.set({ removedDefaultSites: removedDefaultSites });
        console.log('Saved removed default sites:', removedDefaultSites);
    } catch (error) {
        console.error('Error saving removed default sites:', error);
    }
}

// Check if current site is whitelisted
function isWhitelisted() {
    return whitelist.includes(currentHostname);
}

// Check if current site is a default whitelisted site
function isDefaultWhitelisted() {
    return customSelectors[currentHostname] && customSelectors[currentHostname].whitelisted;
}

// Update UI based on whitelist status
function updateUI() {
    if (isWhitelisted()) {
        // Site is whitelisted - show remove button
        whitelistBtn.className = 'btn btn-remove';
        btnTextEl.textContent = 'Remove from whitelist';
        whitelistBtn.querySelector('svg').innerHTML = `
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
        `;
        statusTextEl.textContent = '✓ Menu is enabled on this site';
        statusTextEl.className = 'status whitelisted';
    } else {
        // Site is not whitelisted - show add button
        whitelistBtn.className = 'btn btn-whitelist';
        btnTextEl.textContent = 'Whitelist this site';
        whitelistBtn.querySelector('svg').innerHTML = `
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
        `;
        statusTextEl.textContent = 'Menu is hidden on this site';
        statusTextEl.className = 'status not-whitelisted';
    }
}

// Toggle whitelist status
async function toggleWhitelist() {
    if (isWhitelisted()) {
        // Remove from whitelist
        whitelist = whitelist.filter(site => site !== currentHostname);

        // If this is a default whitelisted site, track it as removed
        if (isDefaultWhitelisted() && !removedDefaultSites.includes(currentHostname)) {
            removedDefaultSites.push(currentHostname);
            await saveRemovedDefaultSites();
        }
    } else {
        // Add to whitelist
        whitelist.push(currentHostname);

        // If this was previously removed from defaults, un-remove it
        if (isDefaultWhitelisted() && removedDefaultSites.includes(currentHostname)) {
            removedDefaultSites = removedDefaultSites.filter(site => site !== currentHostname);
            await saveRemovedDefaultSites();
        }
    }

    await saveWhitelist();
    updateUI();

    // Notify content script about the change
    const tabs = await browserAPI.tabs.query({ active: true, currentWindow: true });
    if (tabs.length > 0) {
        try {
            await browserAPI.tabs.sendMessage(tabs[0].id, {
                type: 'WHITELIST_CHANGED',
                whitelist: whitelist,
                hostname: currentHostname,
                isWhitelisted: isWhitelisted()
            });
        } catch (e) {
            console.log('Could not notify content script:', e);
        }
    }
}

// Event listeners
whitelistBtn.addEventListener('click', toggleWhitelist);

// Initialize on load
init();
